
#include <stdlib.h>
#include <stdio.h>

// Archivo con varias declaraciones de matrices
#include "matrices.h"

// Este código fue obtenido desde https://github.com/miloyip/svpng
#include "svpng.inc"

// Función que sirve para escribir una imagen PNG a partir de 3 matrices RGB
void escribir_imagen(const char* nb, int f, int c, unsigned char R[f][c], unsigned char G[f][c],
		     unsigned char B[f][c]) {
    unsigned char rgb[f * c * 3], *p = rgb;
    unsigned x, y;

    // La imagen resultante tendrá el nombre dado por la variable 'nb'
    FILE *fp = fopen(nb, "wb");

    // Transformamos las 3 matrices en una arreglo unidimensional
    for (y = 0; y < f; y++)
        for (x = 0; x < c; x++) {
            *p++ = R[y][x];    /* R */
            *p++ = G[y][x];    /* G */
            *p++ = B[y][x];    /* B */
        }
    // La función svpng() transforma las 3 matrices RGB en una imagen PNG 
    svpng(fp, c, f, rgb, 0);
    fclose(fp);
}

   /* IGNORAR TODO EL CODIGO ANTERIOR, ES INDISPENSABLE PARA EL DESARROLLO DEL CODIGO PERO NO ES
      NECESARIO QUE LO ENTIENDAN (POR AHORA) */



int main() {

  // Generamos la imagen PNG dada por las matrices s_R, s_G y s_B

  escribir_imagen("mario_chiquito.png", 322, 256, s_R, s_G, s_B);
  
  /*

    Escriba a partir de aqui su codigo, no olvide incluir math
    Las matrices s_R, s_G y s_B son sobre las que deben iterar para modificar la imagen
    
   */
  // Generamos la imagen PNG dada por las matrices s_R, s_G y s_B
  escribir_imagen("mario_chiquito_out.png", 322, 256,s_R, s_G, s_B);
  
  return 0;
}
