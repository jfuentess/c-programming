//Compilar con: gcc correccion_gamma.c -o gamma -lm

#include <stdlib.h>
#include <stdio.h>

//Incluimos math para usar funciones matematicas
#include <math.h>

// Archivo con varias declaraciones de matrices
#include "matrices.h"

// Este código fue obtenido desde https://github.com/miloyip/svpng
#include "svpng.inc"

// Función que sirve para escribir una imagen PNG a partir de 3 matrices RGB
void escribir_imagen(const char* nb, int f, int c, unsigned char R[f][c], unsigned char G[f][c],
		     unsigned char B[f][c]) {
    unsigned char rgb[f * c * 3], *p = rgb;
    unsigned x, y;

    // La imagen resultante tendrá el nombre dado por la variable 'nb'
    FILE *fp = fopen(nb, "wb");

    // Transformamos las 3 matrices en una arreglo unidimensional
    for (y = 0; y < f; y++)
        for (x = 0; x < c; x++) {
            *p++ = R[y][x];    /* R */
            *p++ = G[y][x];    /* G */
            *p++ = B[y][x];    /* B */
        }
    // La función svpng() transforma las 3 matrices RGB en una imagen PNG 
    svpng(fp, c, f, rgb, 0);
    fclose(fp);
}

   /* IGNORAR TODO EL CODIGO ANTERIOR, ES INDISPENSABLE PARA EL DESARROLLO DEL CODIGO PERO NO ES
      NECESARIO QUE LO ENTIENDAN (POR AHORA) */



int main() {

  // Generamos la imagen PNG dada por las matrices s_R, s_G y s_B
  // Las matrices s_R, s_G y s_B son sobre las que deben iterar para modificar la imagen
  
  escribir_imagen("mario_chiquito.png", 322, 256, s_R, s_G, s_B);

  //Creamos las matrices correspondientes a cada matriz R,G,B

  // Creamos una variable donde guardaremos el exponente
  float exponente;
  printf("Ingrese un valor para el exponente de la correccion gamma\n");
  printf("Recuerde:\nExponente > 1 oscurece la imagen\nExponente < 1 aclara la imagen\nExponente = 1 no cambia\n");

  //Pedimos el valor por teclado
  printf("Ingrese un valor para el exponente: ");
  scanf("%f", &exponente);

  printf("##########################################################\n");
  printf("########### SE HA APLICADO LA CORRECCION GAMMA ###########\n");
  printf("##########################################################\n\n");


  //Recorremos cada indice de cada matriz realizando el respectivo calculo
  for(int i=0; i < 322; i++) { // Filas
    for(int j=0; j < 256; j++) { // Columnas
      s_R[i][j] = ( 255 * pow((float)s_R[i][j]/255, exponente));
      s_G[i][j] = ( 255 * pow((float)s_G[i][j]/255, exponente));
      s_B[i][j] = ( 255 * pow((float)s_B[i][j]/255, exponente));
    }
  }

  // Generamos la imagen PNG dada por las matrices s_R, s_G y s_B
  escribir_imagen("mario_chiquito_gamma.png", 322, 256, s_R, s_G, s_B);
  
  return 0;
}
