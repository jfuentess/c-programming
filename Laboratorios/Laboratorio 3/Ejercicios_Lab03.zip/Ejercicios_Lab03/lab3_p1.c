#include <stdio.h>

int main() {
	printf("Ingrese el tamaño de la matriz\n");
	int n;
	scanf("%d", &n);
	printf("Ingresa los valores de la matriz de izquierda a derecha\n");
	int matriz[n][n];
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
			scanf("%d", &matriz[i][j]);
		}
	}
    int inicioFila = 0, inicioColumna = 0;
    int finFila = n - 1, finColumna = n - 1;

    while (inicioFila <= finFila && inicioColumna <= finColumna) {
        for (int i = inicioColumna; i <= finColumna; i++) {
            printf("%d ", matriz[inicioFila][i]);
        }
        inicioFila++;

        for (int i = inicioFila; i <= finFila; i++) {
            printf("%d ", matriz[i][finColumna]);
        }
        finColumna--;

        if (inicioFila <= finFila) {
            for (int i = finColumna; i >= inicioColumna; i--) {
                printf("%d ", matriz[finFila][i]);
            }
            finFila--;
        }

        if (inicioColumna <= finColumna) {
            for (int i = finFila; i >= inicioFila; i--) {
                printf("%d ", matriz[i][inicioColumna]);
            }
            inicioColumna++;
        }
    }

    return 0;
}
