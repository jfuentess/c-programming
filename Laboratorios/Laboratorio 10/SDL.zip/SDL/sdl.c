#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

#define SIZE 80

// Funcion que obtiene las dimensiones de una matriz cualquiera guardada en un txt
void dimen(const char* nombreMapa, int* f, int* c){  
  *f = 0;
  *c = 0;
  int temp1;
  char e;
  FILE *file = fopen(nombreMapa, "r");
  // Contamos todos los saltos de linea para obtener las filas
  
  while ((e = fgetc(file)) != EOF) {                      
    if (e == '\n') {
      (*f)++;  
    }
  }
  rewind(file);
  
  // Contamos cuantos elementos hay en la primera fila para obtener el numero de columnas
  
  while (1) {
    e = fgetc(file);
    if(isdigit(e)){
      (*c)++;}
    else if (e =='\n' || e == EOF) {                     
      return;  
    }
  }
  rewind(file);                                    
  fclose(file);
}

// Creamos una matriz con memoria dinamica para usar en nuestro programa
void cargarMapa(const char * nombreMapa, int ** A, int f, int c){         
  FILE *file = fopen(nombreMapa, "r");
  for (int i = 0; i < f; i++) {                                   
    for (int j = 0; j < c; j++) {
      fscanf(file, "%d", &A[i][j]);
    }
  }
  fclose(file);
}

int main(){
  // Definimos variables y se las pasamos a las funciones para que tengan valores
  // Notar que trabajamos con punteros para hacer esto, por ende pasamos direcciones de memoria
  int filas= 0;
  int columnas= 0;
  dimen("matriz.txt", &filas , &columnas);
  int **A = malloc(filas * sizeof(int*));

  for(int i = 0; i< filas ; i++)
    A[i] = malloc(columnas * sizeof(int));

  cargarMapa("matriz.txt", A , filas, columnas);

  // Mostramos la matriz para asegurarnos que se guardo bien
  for (int i = 0; i < filas; i++) {                                   
    for (int j = 0; j < columnas; j++) {
      printf("%d ", A[i][j]);
    }
    printf("\n");
  }

  // Iniciamos las componentes de SDL que vamos a utilizar 

  if (SDL_Init(SDL_INIT_VIDEO) != 0) {
    printf("Error SDL_Init: %s\n", SDL_GetError());
    return 1;
  }

  if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
    printf("Error IMG_Init: %s\n", IMG_GetError());
    SDL_Quit();
    return 1;
  }

  //Creamos la ventana principal de nuestro programa
  SDL_Window* window = SDL_CreateWindow("Mapa SDL", 
					SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 
					columnas*SIZE, filas*SIZE, SDL_WINDOW_SHOWN);

  //Creamos el renderer Importante!
  SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
  
  // Array con espacio para 3 texturas
  SDL_Texture* img[3];

  //Cargamos cada Surface usando las rutas relativas de las imagenes 
  SDL_Surface* surface1 = IMG_Load("E1.png");
  SDL_Surface* surface2 = IMG_Load("E2.png");
  SDL_Surface* surface3 = IMG_Load("PJ.png");

  //Metemos al array cada textura ya creada 
  img[0] = SDL_CreateTextureFromSurface(renderer, surface1);
  img[1] = SDL_CreateTextureFromSurface(renderer, surface2);
  img[2] = SDL_CreateTextureFromSurface(renderer, surface3);

  //Liberamos las surfaces
  SDL_FreeSurface(surface1);
  SDL_FreeSurface(surface2);
  SDL_FreeSurface(surface3);

  /*IMPORTANTE liberar todo lo que usemos, SDL guarda muchas cosas en buffers lo que puede provocar problemas
    con los recursos de la ram si no se si libera durante mucho tiempo*/
  /*RECOMENDACION, para cargar texturas y manejarlas, es recomendable tenerlas guardadas en structs para acceder y procesarlas
    de forma mas comoda y elegante, a su vez usar ciclos para cargarlas en caso de ser muchas */

  //Definimos el Rect, recordar que es importante para decirle a sdl que porte tendra la imagen y donde estara
  SDL_Rect dst;
  dst.w = SIZE;
  dst.h = SIZE;

  /*Posiciones relativas para ubicar a nuestro personaje, en la practica no deberian ser valores fijos, si no que deberian tener funciones que
    sepan identificar donde estan sus PJ en todo momento, para saber sobre cual iterar */
  int posX = 1;
  int posY = 1;
 
  // Bucle de eventos: esperar a que el usuario cierre la ventana
  
  SDL_Event e;
  int running = 1;
  while (running) {
    while (SDL_PollEvent(&e)) {
      if (e.type == SDL_QUIT) {
	running = 0;
      }
      // En caso de detectar un evento de tipo declado, creamos casos para los que nos interecen
      // Aqui movemos el PJ de posicion, dependiendo de lo que se haya apretado, recordar usar "break" cuando se trabaja con switch
      // En la practica en esta parte deberian ir funciones relacionadas al movimiento, deberian solo llamar algo del estilo "mover_arriba()"
      // Cosa que debe estar generalizada y bien implementada por parte del encargado de la logica
      else if (e.type == SDL_KEYDOWN) {
	switch (e.key.keysym.sym) {
	case SDLK_w:
	  A[posX][posY] = 0;
	  A[--posX][posY] = 2;
	  break;
	case SDLK_a:
	  A[posX][posY] = 0;
	  A[posX][--posY] = 2;
	  break;
	case SDLK_s:
	  A[posX][posY] = 0;
	  A[++posX][posY] = 2;
	  break;
	case SDLK_d:
	  A[posX][posY] = 0;
	  A[posX][++posY] = 2;
	  break;
	}
      }
    }
    // Recordar limpiar el renderer siempre que vaya a dibujar otra vez, de otra forma las imagenes se dibujaran sobre si mismas 
    SDL_RenderClear(renderer);

    //Recorremos todos los elementos de la matriz
    for (int i = 0; i < filas; i++) {
      for (int j = 0; j < columnas; j++) {

        // Asignamos posicion al rect usando el indice del elemento y el size definido
	dst.x = j * SIZE;
	dst.y = i * SIZE;
	switch(A[i][j]){
	  // Hacemos casos para los valores que nos interecen
	  //Notar que con 1 formamos los bordes del mapa, y hacemos uso de una funcion de sdl que permite rotar imagenes para reutlizar solo 2 assets 
	case 1:
	  if(i == 0 & j== 0)
	    SDL_RenderCopyEx(renderer, img[0], NULL, &dst, 0, NULL, SDL_FLIP_NONE);
	  else if ( i == 0 & j == columnas -1)
	    SDL_RenderCopyEx(renderer, img[0], NULL, &dst, 90, NULL, SDL_FLIP_NONE);
	  else if ( i == filas-1 & j == 0)
	    SDL_RenderCopyEx(renderer, img[0], NULL, &dst, 270, NULL, SDL_FLIP_NONE);
	  else if ( i == filas -1 & j == columnas -1)
	      SDL_RenderCopyEx(renderer, img[0], NULL, &dst, 180, NULL, SDL_FLIP_NONE);
	  else if ( i == 0)
	     SDL_RenderCopyEx(renderer, img[1], NULL, &dst, 270, NULL, SDL_FLIP_NONE);
	  else if ( j == 0)
	     SDL_RenderCopyEx(renderer, img[1], NULL, &dst, 180, NULL, SDL_FLIP_NONE);
	  else if (i == filas -1)
	     SDL_RenderCopyEx(renderer, img[1], NULL, &dst, 90, NULL, SDL_FLIP_NONE);
	   else if (j == columnas -1)
	     SDL_RenderCopyEx(renderer, img[1], NULL, &dst, 0, NULL, SDL_FLIP_NONE);
	  break;
	case 0:	  
	  break;
	case 2:
	  SDL_RenderCopy(renderer, img[2], NULL, &dst);
	  break;
	  
	}
      }
    }

    // Presentamos lo que dibujamos 
    SDL_RenderPresent(renderer);
    
    // Definimos un delay simulando una velocidad de 60 fps 
    SDL_Delay(16); 
  }
}
