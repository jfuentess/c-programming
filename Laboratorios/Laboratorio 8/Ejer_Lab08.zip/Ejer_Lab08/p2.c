#include <stdio.h>

int main(int argc, char const *argv[])
{
	char str[] = "bananas";
	long long resultado = 0;

	// Casteamos el tipo de dato del puntero y accedemos a su valor
	resultado = *(long long*)str;

	printf("%lld\n",resultado);

	return 0;
}
