#include <stdio.h>


void mi_función_swap(int* a,int* b){

	int aux;
	aux = *a;
	*a = *b;
	*b = aux;
}

int main(int argc, char const *argv[])
{
	int a = 2, b = 348;
	printf("Antes de la función swap %d %d\n", a,b);
	mi_función_swap(&a,&b);
	printf("Después de la función swap %d %d\n", a,b);
	return 0;
}