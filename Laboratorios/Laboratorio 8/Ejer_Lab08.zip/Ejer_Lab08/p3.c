#include "stdio.h"
#include "string.h"

#define _STR_SIZE 1000

int main()
{
  // Se define un string de largo 1000
  char str[_STR_SIZE];
  // Se obtiene la entrada escrita por consola
  fgets(str,_STR_SIZE,stdin);

  // Puntero al string
  char *token = str;

  printf("%s\n", token);
  for (int i = 0; i < _STR_SIZE && i < strlen(str); i++){
    if (str[i] == ' '){      // En caso de encontrar un espacio, movemos el puntero 1 + i para acceder al comienzo de la siguiente palabra
      token = str + i +1;
      printf("%s\n", token);
    }
  }

  return 0;
}
