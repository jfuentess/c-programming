#include <stdio.h>
#include <stdlib.h>

typedef struct{
  char nombre[100];
  int matricula;
  float ev1;
  float ev2;
  float ev3;
  float promedio;
}alumno;

int main(){
  int n;
  printf("INGRESE EL NUMERO DE ESTUDIANTES A EVALUAR\n");
  scanf("%d", &n);
  //Creamos el array con las estructuras usando malloc
  alumno *alumnos = malloc(n * sizeof(alumno));

  for (int i = 0; i < n; i++) {
    //Pedimos el nombre y lo guardamos dentro de la pos sub i de la struct
    //Proceso analogo para el resto de parametros
    printf("Ingrese el nombre del estudiante: ");
    scanf(" %[^\n]", alumnos[i].nombre); 

    printf("Ingrese matrícula: ");
    scanf("%d", &alumnos[i].matricula);

    printf("Ingrese 3 notas: ");
    scanf("%f %f %f", &alumnos[i].ev1, &alumnos[i].ev2, &alumnos[i].ev3);
    // Calculamos el promedio con las notas guardadas
    alumnos[i].promedio = (alumnos[i].ev1 + alumnos[i].ev2 + alumnos[i].ev3) / 3.0f;
  }
  for(int i = 0; i<n; i++){
    //Mostramos cada dato
    printf("Nombre: %s\n", alumnos[i].nombre);
    printf("Matricula: %d\n",alumnos[i].matricula);
    printf("Promedio: %f\n", alumnos[i].promedio);

    //Decidimos quien paso el ramo
    if(alumnos[i].promedio>=3.95)
      printf("Condicion: APROBADO\n");
    else
      printf("Condicion: REPROBADO\n");
    printf("\n");
  }
  free(alumnos);
}

    
  
  
  
