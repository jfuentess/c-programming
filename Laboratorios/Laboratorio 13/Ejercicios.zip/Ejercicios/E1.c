#include <stdio.h>
#include <stdlib.h>

typedef struct{
  float x;
  float y;
  float z;
  float valor;
}Punto;

float valFunc(float a, float b, float c){
  return a*a*a*a - 2*a*a + b*b + c*c;
}

int main(){
  int n;
  float min;
  float max;
  printf("Ingrese la cantidad de puntos a evaluar\n");
  scanf("%d",&n);
  Punto* puntos = malloc(n * sizeof(Punto));

  for(int i = 0; i<n; i++){
    printf("Ingrese los valores x y z del punto\n");
    scanf("%f %f %f", &puntos[i].x,&puntos[i].y,&puntos[i].z);
    puntos[i].valor = valFunc(puntos[i].x,puntos[i].y,puntos[i].z);
  }
  min = puntos[0].valor;
  max = puntos[0].valor;
  for(int i = 1; i<n;i++){
    if(puntos[i].valor > max)
      max = puntos[i].valor;
    if(puntos[i].valor < min)
      min = puntos[i].valor;
  }
  printf("Valor maximo: %f\n",max);
  printf("Valor minimo: %f\n",min);
  free(puntos);
}
    
  
  
			 
  
