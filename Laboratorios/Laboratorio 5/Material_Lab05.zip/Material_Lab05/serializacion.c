#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 10000000
int arreglo[N];

void llenar_arreglo(){
  srand(time(NULL));  // Semilla para rand()
  for (int i = 0; i < N; i++) {
    arreglo[i] = (rand() % 9000000) + 1000000; 
  }
}

int main(){
  clock_t start, end;
  double tiempo;
  llenar_arreglo();

  //El codigo anteior rellena una array de N elementos con numeros grandes
  //A partir de aqui, escriba su solucion, entre el "start y el end", para ver el tiempo de ejecucion

  // Serializacion Binaria

  start = clock();  // Iniciar aqui















  
  // Terminar codigo antes de este punto
  end = clock();
  tiempo = ((double)(end -start)) / CLOCKS_PER_SEC;
  printf("Tiempo se serializacion binaria: %.6f segundos\n", tiempo);

  
  //Lectura binaria

  start = clock(); // Iniciar aqui














  //Terminar codigo antes de este punto
  end = clock();
  tiempo = ((double)(end -start)) / CLOCKS_PER_SEC;
  printf("Tiempo de lectura binaria: %.6f segundos\n", tiempo);

  }
