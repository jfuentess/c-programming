#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 10000000
int arreglo[N];

void llenar_arreglo(){
  srand(time(NULL));  // Semilla para rand()
  for (int i = 0; i < N; i++) {
    arreglo[i] = (rand() % 9000000) + 1000000; 
  }
}

int main(){
  clock_t start, end;
  double tiempo;
  llenar_arreglo();

  //El codigo anteior rellena una array de N elementos con numeros grandes
  //A partir de aqui, escriba su solucion, entre el "start y el end", para ver el tiempo de ejecucion

  // Serializacion Binaria

  start = clock();  // Iniciar aqui
  
  FILE *fbin = fopen("Serializacion.bin","wb");  //Abrimos un archivo en escritura binaria

  fwrite(arreglo, sizeof(int),N,fbin);          // Escribimos todos los numeros del arreglo en el archivo 
  fclose(fbin);                                //Cerramos 

  // Terminar codigo antes de este punto
  end = clock();
  tiempo = ((double)(end -start)) / CLOCKS_PER_SEC;
  printf("Tiempo se serializacion binaria: %.6f segundos\n", tiempo);

  //Seriazliacion en texto
  start = clock();  
  
  FILE *ftxt = fopen("Serializacion.txt","w");       //Abrimos el archivo en modo escritura
  
  for(int i = 0; i<N; i++){                         //Recorremos todo el array escribiendo los numeros en el texto
    fprintf(ftxt, "%d\n",arreglo[i]);
  }
  fclose(ftxt);

  end = clock();
  tiempo = ((double)(end -start)) / CLOCKS_PER_SEC;
  printf("Tiempo se serializacion en texto: %.6f segundos\n", tiempo);

  //Lectura binaria
  
  start = clock();
  fbin = fopen("Serializacion.bin","r");          //Abrimos el archivo en modo lectura 

  fseek(fbin, 0L,SEEK_END);                      //Movemos el puntero del archivo al final del archivo
 
  long int num_bytes = ftell(fbin);             //ftell nos entrega la posicion en la que estamos en bytes 
  long int num_ints  = num_bytes / sizeof(int);  // Calculamos la cantidad de numeros enteros 
  
  fclose(fbin);
  printf("El archivo tiene %ld bytes, correspondientes a %ld valores enteros\n", num_bytes, num_ints);
 
  end = clock();
  tiempo = ((double)(end -start)) / CLOCKS_PER_SEC;
  printf("Tiempo de lectura binaria: %.6f segundos\n", tiempo);

  // Lectura en txt
  start = clock();
  
  ftxt = fopen("Serializacion.txt","r");                  //Abrimos el txt en modo lectura
  
  num_ints = 0;                                              
  num_bytes = 0;
  char num[100];                                //Creamos un buffer auxiliar
  
  while(fgets(num, 100,ftxt)!=NULL){           //Ciclo que lee todas lineas y suma uno a la cantidad de numeros enteros (Hay un numero por cada linea, esto por la forma en que escribimos el archivo)
    num_ints++;
  }
  num_bytes = num_ints * 4;                 //Calculamos la cantidad de bytes 
  fclose(ftxt);

  end = clock();
  tiempo = ((double)(end -start)) / CLOCKS_PER_SEC;
  printf("El archivo tiene %ld bytes, correspondientes a %ld valores enteros\n", num_bytes, num_ints);
  printf("Tiempo de lectura en texto : %.6f segundos\n", tiempo);
  
  }
