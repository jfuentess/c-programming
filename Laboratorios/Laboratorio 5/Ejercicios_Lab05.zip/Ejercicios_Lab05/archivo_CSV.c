#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#define MAX_LINE 2000

int main(){
  //Abrimos el archivo en modo lectura
  FILE *file = fopen("games-data.csv","r");


  //BUffer donde guardamos las lineas que vamos a leer
  char buffer[MAX_LINE];

  //Punteros a char para guardar los tokens
  char *token;
  char *name;
  char splitter[] = ",";   //Establecemos un separador una ',' en este caso

  //Variables para el checkeo
  int p_min;
  int p_max;

  //Ciclo de validacion de entrada
  do{
    printf("Ingrese un valor minimo y maximo respectivamente\n");
    printf("Puntuacion minima: ");
    scanf("%d",&p_min);
    printf("Puntuacion maxima: ");
    scanf("%d",&p_max);
    printf("\n");
    
    if((p_min == p_max) || (p_min < 0) || (p_max > 100)){
      printf("Ingrese valores distintos en el rango 0 - 100\n");
    }
  } while ((p_min == p_max) || (p_min < 0) || (p_max > 100));


  //Ejecutamos un while hasta que no queden lineas por leer
  while (fgets(buffer, MAX_LINE, file) != NULL) {
    //Obtenemos el nombre del juego de la linea y lo guardamos en name
    token = strtok(buffer, splitter);
    name = token;

    //Tokenizamos hasta encontrar la puntuacion del juego
    for(int i = 0; i < 4; i++){
      token = strtok(NULL, splitter);
    }

    //Pasamos a entero el puntaje contenido el token
    int score = atoi(token);

    //Comprobamos si esta dentro del rango e imprimimos 
    if (score >= p_min && score <= p_max) {
      printf("%s: %d\n",name,score);
    }

  }
  fclose(file);  //Cerramos el archivo (No es necesario pero es una buena practica)
}

      
